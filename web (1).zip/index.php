<?php

include "db_config.php";
session_start();

function adminkey(){
	return md5(time().rand(1,999999)."whoisadmin");
}

function isadmin(){
	if($_SESSION['is_admin'] == 'Y' && $_SESSION['userid'] == 'admin'){
		return true;
	}
	else{
		return false;
	}
	
}

if( isadmin() && isset($_POST[json]) ){

	$json = json_decode($_POST[json]);
	sleep(1);
	if( $json->admin_key == adminkey() ){
		$res = ["res" => true, "flag" => "????????????????????????"];
	}
	else{
		$res = ["res" => false];
	}
	exit(json_encode($res));
}

?><html>
	<head>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	</head>
		
	<body>
		<?php
			if( isadmin() ){
		?>
		Congratulation!!!!</br>
		First flag is : ????????????????????????
		<form method="POST" action="index.php">
			<input type="text" name="json" id="json">
			<input type="button" id="btn" value="check">
		</form>
		<?php
			}
		?>


		<?php
			if( !empty($_SESSION['userid']) ){
		?>
		<center>
			MY ID : <?php echo $_SESSION['userid']; ?>
			<input type="button" value="logout" onclick="location.href='logout.php'">
			</br>
			</br>
			<img src="codered.png">
		</center>
		<?php
			}
			else{
		?>
		
		<center>
			LOGIN </br></br>
			<form method="POST" action="login.php">
				ID : <input type="text" name="userid"></br>
				PW : <input type="text" name="password"></br></br>
				<input type="submit" value="login"> <input type="button" value="join" onclick="location.href='join.php'">
			</form>
		</center>
		<?php
			}
		?>
	</body>

	<script>
		$("#btn").click(function(){
			$.ajax({
				type:"POST",
				url: "./index.php",
				data: {json: JSON.stringify({admin_key: $("#json").val()}) },
				dataType : 'json'
			}).done(function(res){
				if( res['res'] == true ){
					alert("flag is " + res['flag']);
				}
				else{
					alert("no!");
				}
			});
		});
	</script>

</html>
