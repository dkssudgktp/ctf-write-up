<?php
	include("db_config.php");

	header('Content-Type: text/html; charset=utf-8');

	session_start();

	$user_id = $_POST['userid'];
	$password = $_POST['password'];

	if( preg_match("/(union)/i",$user_id) || preg_match("/(union)/i",$password) ){
		exit("hack?");
	}
	
	if( strlen($password) <= 15 ){
		echo "<script>alert('비밀번호가 너무 짧습니다.'); history.go(-1);</script>";
	}	

	$check = mysql_fetch_array(mysql_query("select * from hkkiw_member where user_id = '".$user_id."' and password = password('".$password."')"));

	if(!$check) {
		echo "<script>alert('아이디가 없거나 비밀번호가 잘못되었습니다.'); history.go(-1);</script>";
	}
	else {
		$_SESSION['userid'] = $user_id;
		if($check['is_admin'] == 'Y') $_SESSION['is_admin'] = 'Y';
		echo "<script>document.location.href='index.php';</script>";
	}
?>
