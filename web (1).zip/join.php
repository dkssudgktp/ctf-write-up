<?php
	include "db_config.php";

	$user_id = $_POST['userid'];
	$password = $_POST['password'];

	if( preg_match("/(union)/i",$user_id) || preg_match("/(union)/i",$password) ){
		exit("hack?");
	}

	if(isset($user_id) && isset($password)){

		$check = mysql_fetch_array(mysql_query("select * from hkkiw_member where user_id = '$user_id'"));

		if($check[0]) {
			echo "<script type=\"text/javascript\">alert('아이디가 중복입니다.'); location.href='join.php';</script>";
			exit();
		}
		
		$query = "insert into hkkiw_member values(NULL, '$user_id', password('$password'), 'N')";

		mysql_query($query) or die("error");
		header('Location: index.php');
	}

?><html>
	<head>
		
	</head>
		
	<body>
		<center>
			JOIN </br></br>
			<form method="POST" action="join.php">
				ID : <input type="text" name="userid"></br>
				PW : <input type="text" name="password"></br></br>
				<input type="submit" value="submit">
			</form>
		</center>
	</body>
</html>